<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Auth::routes();
Route::get('api/login', 'ApiController@login');
Route::get('api/money', 'ApiController@money_list');
Route::get('api/money/{id}', 'ApiController@money_detail');
Route::get('api/money/check/{user_id}/{id}/{password}', 'ApiController@money_check');
Route::get('api/money/status/{id}', 'ApiController@money_status');
Route::get('api/province', 'ApiController@province');
Route::get('api/district/{id}', 'ApiController@district');
Route::get('api/ward/{id}', 'ApiController@ward');
Route::get('api/password', 'ApiController@change_password');


Route::group(['middleware' => ['auth']], function () {
    Route::get('/','UsersController@manager_list')->name('manager.index');
    Route::resource('users', 'UsersController');
    Route::resource('recipients', 'RecipientsController');

    Route::post('import', 'UsersController@user_import')->name('import');

    Route::get('money', 'UsersController@money_list')->name('money.index');
    Route::get('money/create', 'UsersController@money_create')->name('money.create');
    Route::post('money/store', 'UsersController@money_store')->name('money.store');
    Route::get('money/delete/{id}', 'UsersController@money_delete')->name('money.delete');


    Route::get('manager', 'UsersController@manager_list')->name('manager.index');
	Route::get('manager/delete/{id}', 'UsersController@manager_delete')->name('manager.delete');
    Route::get('manager/create', 'UsersController@manager_create')->name('manager.create');
    Route::post('manager/store', 'UsersController@manager_store')->name('manager.store');


    Route::get('area', 'UsersController@area_list')->name('area.index');
    Route::get('area/delete/{id}', 'UsersController@area_delete')->name('area.delete');
    Route::get('area/create', 'UsersController@area_create')->name('area.create');
    Route::post('area/store', 'UsersController@area_store')->name('area.store');


    Route::get('province', 'HomeController@province');
    Route::get('district/{id}', 'HomeController@district');
    Route::get('ward/{id}', 'HomeController@ward');
});