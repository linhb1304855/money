<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="<?php echo e(route('users.create')); ?>" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người dùng</a>

                <?php echo e(Form::open(['url' => route('users.index'), 'method' => 'get' ])); ?>

                    <div class="row">
                        <div class="col-md-3">
                            <input type="text" value="<?php echo e(isset($request['key_word']) ? $request['key_word'] : ''); ?>" class="form-control" name="key_word" placeholder="Nhập tên hoặc email...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" name="role">
                                <option name="key_word_role" value="">--Chọn loại tài khoản--</option>
                                <option name="key_word_role" <?php echo e(isset($request['role']) && $request['role'] == 'admin' ? 'selected' : ''); ?> value="admin">Quản trị</option>
                                <option name="key_word_role" <?php echo e(isset($request['role']) && $request['role'] == 'employee' ? 'selected' : ''); ?> value="employee">Nhân viên</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-info">Tìm kiếm</button>
                        </div>
                    </div>
                <?php echo Form::close(); ?>


                <div class="card-header"><h3 style="text-align: center">QUẢN LÝ NGƯỜI DÙNG</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh đại diện</th>
                                <th scope="col">Loại người dùng</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Số điện thoại</th>
                                <th scope="col">Địa chỉ</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td>
                                        <img src="<?php echo e(url('images') . '/' . $user->image); ?>" id="output" style="width: 100px; height: 100px"/>
                                    </td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone_number); ?></td>
                                    <td><?php echo e($user->address); ?></td>
                                    <td>
                                        <a  href="/usecase/public/users/<?php echo e($user->id); ?>/edit" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                        <?php echo Form::open(['action' => ['UsersController@destroy', $user->id], 'method' => 'POTS', 'class' => 'pull-right']); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo e(Form::submit('Xóa', ['class' => 'btn btn-danger'])); ?>

                                        <?php echo Form::close(); ?>


                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\usecase\resources\views/users/list.blade.php ENDPATH**/ ?>