<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <ul class="navbar-nav ml-auto">
                </ul>
                <div class="card-header"><h3 style="text-align: center">LOẠI CHI TRẢ</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table" >
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Mã loại</th>
                                <th scope="col">Tên loại</th>
                                <th scope="col">Hệ số </th>
                                <th scope="col">Mức</th>
                                <th scope="col">Ghi chú</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>dv</td>
                                    <td>Phí dịch vụ</td>
                                    <td>3.46</td>
                                    <td>07</td>
                                    <td></td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\usecase\resources\views/tradings/payment.blade.php ENDPATH**/ ?>