<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <a href="/usecase/public/users/list" style="margin-bottom: 10px;" class="btn btn-secondary">Go Back</a>
                <div class="card">
                    <div class="card-header"><h2>TẠO NGƯỜI DÙNG</h2></div>
                    <div class="card-body">
                        <?php echo e(Form::open(['url' => route('users.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ])); ?>


                        <div class="form-group">
                            <label for="formGroupExampleInput2">Loại người dùng</label>
                            <select class="form-control" name="role">
                                <option value="admin">Quản trị</option>
                                <option value="employee">Nhân viên</option>
                                <option value="receiver">Người nhận</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Tên người dùng</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput">Email</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Mật khẩu</label>
                            <input type="password" class="form-control" name="password" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Xác nhận lại mật khẩu</label>
                            <input type="password" class="form-control" name="password_confirmation" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày sinh</label>
                            <input type="date" class="form-control" name="birthday" value="<?php echo e(old('birthday')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số điện thoại</label>
                            <input type="text" class="form-control" name="phone_number" value="<?php echo e(old('phone_number')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Địa chỉ</label>
                            <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ảnh người dùng</label>
                            <input type="file" accept="image/*" onchange="loadFile(event)" name="image" class="form-control">
                            <img id="output" style="width: 200px; height: 200px; margin-top: 10px"/>
                            <script>
                                var loadFile = function(event) {
                                    var reader = new FileReader();
                                    reader.onload = function(){
                                        var output = document.getElementById('output');
                                        output.src = reader.result;
                                    };
                                    reader.readAsDataURL(event.target.files[0]);
                                };
                            </script>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số Chứng minh nhân dân</label>
                            <input type="text" class="form-control" name="id_card" value="<?php echo e(old('id_card')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày cấp CMND</label>
                            <input type="date" class="form-control" name="date_card" value="<?php echo e(old('date_card')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Nơi cấp CMND</label>
                            <input type="text" class="form-control" name="place_card" value="<?php echo e(old('place_card')); ?>" >
                        </div>

                        <button type="submit">Tạo tài khoản</button>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\usecase\resources\views/users/create.blade.php ENDPATH**/ ?>