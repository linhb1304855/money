<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <a href="/usecase/public/users/list"  style="margin-bottom: 10px;" class="btn btn-secondary">Go Back</a>
                <div class="card">
                    <div class="card-header"><h3>CẬP NHẬT TÀI KHOẢN</h3></div>
                    <div class="card-body">
                        <?php echo e(Form::open(['url' => route('users.update', $users->id), 'method' => 'POST', 'enctype' => 'multipart/form-data' ])); ?>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <?php echo e(Form::label('role', 'Loại người dùng')); ?>

                            <select class="form-control" name="role" >
                                <?php if($users->role =="admin"): ?>
                                    <option value="admin" selected="selected">Quản trị</option>
                                    <option value="employee">Nhân viên</option>
                                    <option value="receiver" >Người nhận</option>
                                <?php elseif($users->role =="employee"): ?>
                                    <option value="admin" >Quản trị</option>
                                    <option value="employee" selected="selected">Nhân viên</option>
                                    <option value="receiver" >Người nhận</option>
                                <?php else: ?>
                                    <option value="admin" >Quản trị</option>
                                    <option value="employee" >Nhân viên</option>
                                    <option value="receiver" selected="selected" >Người nhận</option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('name', 'Tên người dùng')); ?>

                            <?php echo e(Form::text('name', $users->name, ['class' => 'form-control', 'placeholder' => 'Tên người dùng'])); ?>


                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('email', 'Email')); ?>

                            <?php echo e(Form::text('email', $users->email, ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('birthday', 'Ngày sinh')); ?>

                            <?php echo e(Form::date('birthday', $users->birthday, ['class' => 'form-control', 'placeholder' => 'Ngày sinh'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('phone_number', 'Số điện thoại')); ?>

                            <?php echo e(Form::text('phone_number', $users->phone_number, ['class' => 'form-control', 'placeholder' => 'Số điện thoại'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('address', 'Địa chỉ')); ?>

                            <?php echo e(Form::text('address', $users->address, ['class' => 'form-control', 'placeholder' => 'Địa chỉ'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ảnh người dùng</label>

                            <img src="<?php echo e(url('images') . '/' . $users->image); ?>" id="output" style="width: 100px; height: 100px"/>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('id_card', 'Số chứng minh nhân dân')); ?>

                            <?php echo e(Form::text('id_card', $users->id_card, ['class' => 'form-control', 'placeholder' => 'So CMND'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('date_card', 'Ngày cấp CMND')); ?>

                            <?php echo e(Form::date('date_card', $users->date_card, ['class' => 'form-control', 'placeholder' => 'Ngày cấp CMND'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('place_card', 'Nơi cấp CMND')); ?>

                            <?php echo e(Form::text('place_card', $users->place_card, ['class' => 'form-control', 'placeholder' => 'Nơi cấp CMND'])); ?>

                        </div>

                        <?php echo e(Form::hidden('_method', 'PUT')); ?>

                        <?php echo e(Form::submit('Cập nhật tài khoản', ['class'=>'btn btn-primary'])); ?>

                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\usecase\resources\views/users/edit.blade.php ENDPATH**/ ?>