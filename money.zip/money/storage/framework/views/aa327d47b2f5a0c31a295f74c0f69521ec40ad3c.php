<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h2>TẠO LỆNH GIAO TIỀN THEO THÁNG</h2></div>
                    <div class="card-body">
                        <?php echo e(Form::open(['url' => route('money.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ])); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Người nhận tiền</label>
                                    <?php echo Form::select('user_id',$user  ,old('user', ''),['id'=>'user','class'=>'form-control','required']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="formGroupExampleInput2">Nhập số tiền</label>
                                <div class="form-group">
                                    <input type="number" class="form-control" name="money" required value="<?php echo e(old('money')); ?>" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="formGroupExampleInput2">Loại tiền</label>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="type" required value="<?php echo e(old('type')); ?>" >
                                </div>
                            </div>
                        </div>


                        <button type="submit" class="btn btn-primary">Xác nhận</button>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\Xampp\htdocs\money\resources\views/money/create.blade.php ENDPATH**/ ?>