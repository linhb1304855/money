<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <a href="/usecase/public/recipients/list" style="margin-bottom: 10px;" class="btn btn-secondary">Go Back</a>
                <div class="card">
                    <div class="card-header"><h3>NHẬP THÔNG TIN NGƯỜI NHẬN</h3></div>
                    <div class="card-body">
                        <?php echo e(Form::open(['url' => route('recipients.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ])); ?>



                        <div class="form-group">
                            <label for="formGroupExampleInput2">Họ và tên người nhận</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày sinh</label>
                            <input type="date" class="form-control" name="birthday" value="<?php echo e(old('birthday')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số điện thoại</label>
                            <input type="text" class="form-control" name="phone_number" value="<?php echo e(old('phone_number')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Địa chỉ</label>
                            <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Tỉnh-Thành phố</label>
                            <select class="form-control" name="city">
                                <option value="Cần Thơ">Cần Thơ</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Quận-Huyện</label>
                            <select class="form-control" name="district">
                                <option value="Cái Răng">Cái Răng</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Xã-Phường</label>
                            <select class="form-control" name="town">
                                <option value="Ba Láng">Ba Láng</option>
                                <option value="Hưng Phú">Hưng Phú</option>
                                <option value="Hưng Thạnh">Hưng Thạnh</option>
                                <option value="Lê Bình">Lê Bình</option>
                                <option value="Phú Thứ">Phú Thứ</option>
                                <option value="Tân Phú">Tân Phú</option>
                                <option value="Thường Thạnh">Thường Thạnh</option>
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số Chứng minh nhân dân</label>
                            <input type="text" class="form-control" name="id_card" value="<?php echo e(old('id_card')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày cấp CMND</label>
                            <input type="date" class="form-control" name="date_card" value="<?php echo e(old('date_card')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Nơi cấp CMND</label>
                            <input type="text" class="form-control" name="place_card" value="<?php echo e(old('place_card')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số tiền</label>
                            <input type="text" class="form-control" name="money" value="<?php echo e(old('money')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Loại tiền</label>
                            <select class="form-control" name="currency">
                                <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                <option value="Thương binh">Thương binh</option>
                                <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>
                            </select>
                        </div>
                        <button type="submit">Lưu người nhận</button>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\usecase\resources\views/recipients/create.blade.php ENDPATH**/ ?>