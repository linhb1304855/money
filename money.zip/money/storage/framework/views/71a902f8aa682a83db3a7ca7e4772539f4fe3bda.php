<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="<?php echo e(route('recipients.create')); ?>" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người nhận</a>

                <?php echo e(Form::open(['url' => route('recipients.index'), 'method' => 'get' ])); ?>

                <div class="row">
                    <div class="col-md-3">
                        <input type="text" value="<?php echo e(isset($request['key_word']) ? $request['key_word'] : ''); ?>" class="form-control" name="key_word" placeholder="Nhập họ tên...">
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="currency">
                            <option name="key_word" value="">-Loại tiền-</option>
                            <option name="key_word" <?php echo e(isset($request['currency']) && $request['currency'] == 'Mẹ Việt Nam anh hùng' ? 'selected' : ''); ?> value="Mẹ Việt Nam anh hùng" >Mẹ Việt Nam anh hùng</option>
                            <option name="key_word" <?php echo e(isset($request['currency']) && $request['currency'] == 'Gia đình có công với cách mạng' ? 'selected' : ''); ?> value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                            <option name="key_word" <?php echo e(isset($request['currency']) && $request['currency'] == 'Gia đình liệt sĩ' ? 'selected' : ''); ?> value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                            <option name="key_word" <?php echo e(isset($request['currency']) && $request['currency'] == 'Thương binh' ? 'selected' : ''); ?> value="Thương binh">Thương binh</option>
                            <option name="key_word" <?php echo e(isset($request['currency']) && $request['currency'] == 'Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng' ? 'selected' : ''); ?> value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="town">
                            <option name="key_word" value="">-Xã - Phường-</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Ba Láng' ? 'selected' : ''); ?> value="Ba Láng">Ba Láng</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Hưng Phú' ? 'selected' : ''); ?> value="Hưng Phú">Hưng Phú</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Hưng Thạnh' ? 'selected' : ''); ?> value="Hưng Thạnh">Hưng Thạnh</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Lê Bình' ? 'selected' : ''); ?> value="Lê Bình">Lê Bình</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Phú Thứ' ? 'selected' : ''); ?> value="Phú Thứ">Phú Thứ</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Tân Phú' ? 'selected' : ''); ?> value="Tân Phú">Tân Phú</option>
                            <option name="key_word" <?php echo e(isset($request['town']) && $request['town'] == 'Thường Thạnh' ? 'selected' : ''); ?> value="Thường Thạnh">Thường Thạnh</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-info">Lọc</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

                <div class="card-header"><h3 style="text-align: center">DANH SÁCH NGƯỜI NHẬN TIỀN</h3></div>
                <div class="card">
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Họ và tên</th>
                                <th scope="col">Ngày sinh</th>
                                <th scope="col">Số điện thoại</th>
                                
                                
                                
                                
                                <th scope="col">Số CMND</th>
                                <th scope="col">Ngày cấp CMND</th>
                                <th scope="col">Nơi cấp CMND</th>
                                <th scope="col">Số tiền</th>
                                <th scope="col">Loại tiền</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($value->name); ?></td>
                                        <td><?php echo e($value->birthday); ?></td>
                                        <td><?php echo e($value->phone_number); ?></td>
                                        
                                        
                                        
                                        
                                        <td><?php echo e($value->id_card); ?></td>
                                        <td><?php echo e($value->date_card); ?></td>
                                        <td><?php echo e($value->place_card); ?></td>
                                        <td><?php echo e($value->money); ?></td>
                                        <td><?php echo e($value->currency); ?></td>
                                        <td>
                                            <a  href="<?php echo e(url('recipients/'.$value->id.'/edit')); ?>" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                            <?php echo Form::open(['action' => ['RecipientsController@destroy', $value->id], 'method' => 'POTS', 'class' => 'pull-right']); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                            <?php echo e(Form::submit('Xóa', ['class' => 'btn btn-danger'])); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\Xampp\htdocs\money\resources\views/recipients/list.blade.php ENDPATH**/ ?>