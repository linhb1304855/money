<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <a href="/usecase/public/recipients/list"  style="margin-bottom: 10px;" class="btn btn-secondary">Go Back</a>
                <div class="card">
                    <div class="card-header"><h3>CẬP NHẬT THÔNG TIN NGƯỜI NHẬN</h3></div>
                    <div class="card-body">
                        <?php echo e(Form::open(['url' => route('recipients.update', $data->id), 'method' => 'POST', 'enctype' => 'multipart/form-data' ])); ?>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Họ và tên người nhận</label>
                            <?php echo e(Form::text('name', $data->name, ['class' => 'form-control'])); ?>

                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày sinh</label>
                            <?php echo e(Form::date('birthday', $data->birthday, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số điện thoại</label>
                            <?php echo e(Form::text('phone_number', $data->phone_number, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Địa chỉ</label>
                            <?php echo e(Form::text('address', $data->address, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Xã-Phường</label>
                            <select class="form-control" name="town">
                                <?php if($data->town =="Hưng Phú"): ?>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Tân Phú">Tân Phú</option>
                                    <option value="Thường Thạnh">Thường Thạnh</option>

                                <?php elseif($data->town =="Hưng Thạnh"): ?>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Tân Phú">Tân Phú</option>
                                    <option value="Thường Thạnh">Thường Thạnh</option>

                                <?php elseif($data->town =="Lê Bình"): ?>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Tân Phú">Tân Phú</option>
                                    <option value="Thường Thạnh">Thường Thạnh</option>

                                <?php elseif($data->town =="Phú Thứ"): ?>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Tân Phú">Tân Phú</option>
                                    <option value="Thường Thạnh">Thường Thạnh</option>

                                <?php elseif($data->town =="Tân Phú"): ?>
                                    <option value="Tân Phú">Tân Phú</option>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Thường Thạnh">Thường Thạnh</option>

                                <?php elseif($data->town =="Thường Thạnh"): ?>
                                    <option value="Thường Thạnh">Thường Thạnh</option>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Tân Phú">Tân Phú</option>

                                <?php else: ?>
                                    <option value="Ba Láng">Ba Láng</option>
                                    <option value="Hưng Phú">Hưng Phú</option>
                                    <option value="Hưng Thạnh">Hưng Thạnh</option>
                                    <option value="Lê Bình">Lê Bình</option>
                                    <option value="Phú Thứ">Phú Thứ</option>
                                    <option value="Tân Phú">Tân Phú</option>
                                    <option value="Thường Thạnh">Thường Thạnh</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Quận-Huyện</label>
                            <select class="form-control" name="district">
                                <option value="Cái Răng">Cái Răng</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Tỉnh-Thành phố</label>
                            <select class="form-control" name="city">
                                <option value="Cần Thơ">Cần Thơ</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số Chứng minh nhân dân</label>
                            <?php echo e(Form::text('id_card', $data->id_card, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày cấp CMND</label>
                            <?php echo e(Form::date('date_card', $data->date_card, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Nơi cấp CMND</label>
                            <?php echo e(Form::text('place_card', $data->place_card, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số tiền</label>
                            <?php echo e(Form::text('money', $data->money, ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Loại tiền</label>
                            <select class="form-control" name="currency">
                                <?php if($data->currency == 'Gia đình có công với cách mạng' ): ?>
                                    <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                    <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                    <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                    <option value="Thương binh">Thương binh</option>
                                    <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>

                                <?php elseif($data->currency == 'Gia đình liệt sĩ'): ?>
                                    <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                    <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                    <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                    <option value="Thương binh">Thương binh</option>
                                    <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>

                                <?php elseif($data->currency == 'Thương binh'): ?>
                                    <option value="Thương binh">Thương binh</option>
                                    <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                    <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                    <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                    <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>

                                <?php elseif($data->currency == 'Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng'): ?>
                                    <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>
                                    <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                    <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                    <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                    <option value="Thương binh">Thương binh</option>

                                <?php else: ?>
                                    <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                    <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                    <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                    <option value="Thương binh">Thương binh</option>
                                    <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php echo e(Form::hidden('_method', 'PUT')); ?>

                        <?php echo e(Form::submit('Lưu cập nhật', ['class'=>'btn btn-primary'])); ?>

                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\Xampp\htdocs\money\resources\views/recipients/edit.blade.php ENDPATH**/ ?>