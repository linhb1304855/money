<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                <a href="<?php echo e(route('manager.create')); ?>" style="margin-bottom: 10px;" class="btn btn-primary">Tạo lệnh giao tiền</a>
                <?php endif; ?>
                <?php echo e(Form::open(['url' => route('manager.index'), 'method' => 'get' ])); ?>

                <div class="row">
                    <div class="col-md-3">
                        <input type="text" value="<?php echo e(isset($request['key_word']) ? $request['key_word'] : ''); ?>" class="form-control" name="key_word" placeholder="Nhập tên ...">
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="month">
                            <option name="key_word_role" value="">-- Chọn tháng --</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                            <option>7</option>
                            <option>8</option>
                            <option>9</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="year">
                            <option name="key_word_role" value="">-- Chọn năm --</option>
                            <option>2019</option>
                            <option>2020</option>
                            <option>2021</option>
                            <option>2022</option>
                            <option>2023</option>
                            <option>2024</option>
                            <option>2025</option>
                            <option>2026</option>
                            <option>2027</option>
                            <option>2028</option>
                            <option>2029</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="status">
                            <option name="key_word_role" value="">-- Trạng thái --</option>
                            <option value="received" >Đã nhận</option>
                            <option value="not received">Chưa nhận</option>
                        </select>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <?php echo Form::select('province',$province  ,old('province', ''),['id'=>'province','class'=>'form-control']); ?>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <?php echo Form::select('district',[]  ,old('district', ''),['id'=>'district','class'=>'form-control']); ?>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <?php echo Form::select('ward',[]  ,old('ward', ''),['id'=>'ward', 'class'=>'form-control']); ?>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-info">Tìm kiếm</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

                <button class="btn btn-success" onclick="tableToExcel('tblData', 'quan-ly-giao-tien')">Xuất dữ liệu</button>
                <div class="card-header"><h3 style="text-align: center">Quản lý Giao tiền</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table" id="tblData">
                            <thead class="thead-light">
                            <tr>
                                <th style="text-align: center">#</th>
                                <th>Họ Tên</th>
                                <th>Tỉnh</th>
                                <th>Huyện</th>
                                <th>Phường</th>
                                <th>Số tiền</th>
                                <th style="text-align: center">Trạng thái</th>
                                <th style="text-align: center">Ngày tháng giao</th>
                                <th>Nhân viên giao</th>
                                <th>Ngày nhận</th>
								<th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center"><?php echo e($key+1); ?></td>
                                    <td><?php echo e($value->users_name); ?></td>
                                    <td><?php echo e($value->province_name); ?></td>
                                    <td><?php echo e($value->district_name); ?></td>
                                    <td><?php echo e($value->ward_name); ?></td>
                                    <td style="color: red;"><?php echo e(number_format($value->money, 0, '', ',')); ?>đ</td>

                                    <td>
									<?php echo e($value->status == 'not received' ? 'Chưa nhận' : 'Đã nhận'); ?>

									</td>
                                    <td><?php echo e($value->month); ?> - <?php echo e($value->year); ?></td>
                                    <td><?php echo e($value->nhanvien ? $value->nhanvien : 'Đang chờ giao'); ?></td>
                                    <td><?php echo e($value->date_confirm ? $value->date_confirm : 'Đang chờ giao'); ?></td>
									<td>
                                        <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
									<?php if($value->status == 'not received'): ?>
                                        <a class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa dòng này ?');" href="<?php echo e(route('manager.delete', $value->id)); ?>">Xóa</a>
                                    <?php endif; ?>
                                            <?php endif; ?>
									</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>

var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
    if (!table.nodeType) table = document.getElementById(table)
    var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
    window.location.href = uri + base64(format(template, ctx))
  }
})()
        var province = '';

        $('#province').change(function (value) {
            $.ajax({
                url : "/money/public/district/" + $('#province').val(),
                type : "get",
                success : function (data){
                    var district = $('#district');
                    console.log(data);
                    district.empty();
                    $('#ward').empty();
                    district.append('<option value="">Chọn Quận Huyện</option>');
                    for (var i = 0; i < data.length; i++) {
                        district.append('<option value=' + data[i].districtid + '>' + data[i].name + '</option>');
                    }
                    district.change();
                }
            });
        });

        $('#district').change(function (value) {
            $.ajax({
                url : "/money/public/ward/" + $('#district').val(),
                type : "get",
                success : function (data){
                    var ward = $('#ward');
                    ward.empty();
                    ward.append('<option value="">Chọn Phường Xã</option>');
                    for (var i = 0; i < data.length; i++) {
                        ward.append('<option value=' + data[i].wardid + '>' + data[i].name + '</option>');
                    }
                    ward.change();
                }
            });
        });


        var loadFile = function(event) {
            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('output');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\Xampp\htdocs\money\resources\views/manager/index.blade.php ENDPATH**/ ?>