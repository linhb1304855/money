<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="<?php echo e(route('users.create')); ?>" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người dùng</a>
                <br>
                <div class="col-md-9">
                    <div class="alert alert-success">
                        <h4><b>Kết quả tìm kiếm</b></h4>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"><h2>QUẢN LÝ NGƯỜI DÙNG</h2></div>
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh đại diện</th>
                                <th scope="col">Loại người dùng</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Số điện thoại</th>
                                <th scope="col">Địa chỉ</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td>
                                        <img src="<?php echo e(url('images') . '/' . $user->image); ?>" id="output" style="width: 100px; height: 100px"/>
                                    </td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone_number); ?></td>
                                    <td><?php echo e($user->address); ?></td>
                                    <td>
                                        <a href="/usecase/public/users/<?php echo e($user->id); ?>/edit" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                        <?php echo Form::open(['action' => ['UsersController@destroy', $user->id], 'method' => 'USER', 'class' => 'pull-right']); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo e(Form::submit('Xóa', ['class' => 'btn btn-danger'])); ?>


                                        <?php echo Form::close(); ?>


                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\usecase\resources\views/users/find.blade.php ENDPATH**/ ?>