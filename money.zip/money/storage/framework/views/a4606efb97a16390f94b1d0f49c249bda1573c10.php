<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="#" style="margin-bottom: 10px;"  data-toggle="modal" data-target="#exampleModal" class="btn btn-primary">Thêm mới</a>

                <?php echo e(Form::open(['url' => route('money.index'), 'method' => 'get' ])); ?>

                <div class="row">
                    <div class="col-md-3">
                        <input type="text" value="<?php echo e(isset($request['key_word']) ? $request['key_word'] : ''); ?>" class="form-control" name="key_word" placeholder="Nhập tên hoặc email...">
                    </div>
                    <div class="col-md-2">
                        <?php echo Form::select('province',$province  ,isset($request['province']) ? $request['province'] : '',['id'=>'province','class'=>'form-control']); ?>

                    </div>
                    <div class="col-md-2">
                        <?php echo Form::select('district',$district  ,isset($request['district']) ? $request['district'] : '',['id'=>'district','class'=>'form-control']); ?>

                    </div>
                    <div class="col-md-2">
                        <?php echo Form::select('ward',$ward  ,isset($request['ward']) ? $request['ward'] : '',['id'=>'ward','class'=>'form-control']); ?>

                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-info">Tìm kiếm</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>


                <div class="card-header"><h3 style="text-align: center">QUẢN LÝ SỐ TIỀN NHẬN</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th style="text-align: center">#</th>
                                <th>Họ Tên</th>
                                <th>Số tiền</th>
                                <th>Loại tiền</th>
                                <th>Tỉnh thành</th>
                                <th>Quận huyện</th>
                                <th>Phường xã</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center"><?php echo e($key+1); ?></td>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e(number_format($value->money, 0, '', ',')); ?> đ</td>
                                    <td><?php echo e($value->type); ?></td>
                                    <td><?php echo e($value->province_name); ?></td>
                                    <td><?php echo e($value->district_name); ?></td>
                                    <td><?php echo e($value->ward_name); ?></td>                                    <td>
                                        <a class="btn btn-primary" onclick="return confirm('Bạn có chắc muốn xóa dòng này ?');" href="<?php echo e(route('money.delete', $value->id)); ?>">Xóa</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <div class="modal" tabindex="-1" role="dialog" id="exampleModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <?php echo e(Form::open(['url' => route('money.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ])); ?>

                <div class="modal-header">
                    <h5 class="modal-title">TẠO LỆNH GIAO TIỀN THEO THÁNG</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="formGroupExampleInput2">Người nhận tiền</label>
                                <?php echo Form::select('user_id',$user  ,old('user', ''),['id'=>'user','class'=>'form-control','required']); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label for="formGroupExampleInput2">Nhập số tiền</label>
                            <div class="form-group">
                                <input type="number" class="form-control" name="money" required value="<?php echo e(old('money')); ?>" >
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="formGroupExampleInput2">Loại tiền</label>
                            <div class="form-group">
                                <input type="text" class="form-control" name="type" required value="<?php echo e(old('type')); ?>" >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-primary">Thêm</button>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

    <script>
        var province = '';

        $('#province').change(function (value) {
            $.ajax({
                url : "/money/public/district/" + $('#province').val(),
                type : "get",
                success : function (data){
                    var district = $('#district');
                    console.log(data);
                    district.empty();
                    $('#ward').empty();
                    district.append('<option value="">Chọn Quận Huyện</option>');
                    for (var i = 0; i < data.length; i++) {
                        district.append('<option value=' + data[i].districtid + '>' + data[i].name + '</option>');
                    }
                    district.change();
                }
            });
        });

        $('#district').change(function (value) {
            $.ajax({
                url : "/money/public/ward/" + $('#district').val(),
                type : "get",
                success : function (data){
                    var ward = $('#ward');
                    ward.empty();
                    ward.append('<option value="">Chọn Phường Xã</option>');
                    for (var i = 0; i < data.length; i++) {
                        ward.append('<option value=' + data[i].wardid + '>' + data[i].name + '</option>');
                    }
                    ward.change();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\Xampp\htdocs\money\resources\views/money/index.blade.php ENDPATH**/ ?>