<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProvinceModel extends Model
{
    protected $table = 'province';
    protected $primaryKey = 'provinceid';
    protected $fillable = ['name'];
    protected $keyType = 'varchar';
}
