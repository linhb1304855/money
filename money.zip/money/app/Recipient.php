<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recipient extends Model
{
    protected $table = 'recipients';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id',
        'name',
        'birthday',
        'phone_number',
        'address',
        'town',
        'district',
        'city',
        'id_card',
        'date_card',
        'place_card',
        'money',
        'currency'
    ];
}
