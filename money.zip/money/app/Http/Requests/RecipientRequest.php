<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RecipientRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'birthday' => 'required',
            'phone_number' => 'required',
            'address' => 'required',
            'id_card' => 'required',
            'date_card' => 'required',
            'place_card' => 'required',
            'money'=> 'required'
        ];
    }
    public function messages()
    {
        return[
            'name.required' => 'Bạn chưa nhập họ tên',
            'birthday.required' => 'Bạn chưa chọn ngày sinh',
            'phone_number.required' => 'Bạn chưa nhập số điện thoại',
            'address.required' => 'Bạn chưa nhập địa chỉ',
            'id_card.required' => 'Bạn chưa nhập số CMND',
            'date_card.required' => 'Bạn chưa chọn ngày cấp CMND',
            'place_card.required' => 'Bạn chưa nhập nơi cấp CMND',
            'money.required' => 'Bạn chưa nhập số tiền'
        ];
    }
}
