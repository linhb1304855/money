<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|min:6',
            'email' => 'required',
//            'password' => 'required|confirmed|min:8',
            'birthday' => 'required',
            'phone_number' => 'required',
            'address' => 'required',
//            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'id_card' => 'required',
            'date_card' => 'required',
            'place_card' => 'required'
            ];
    }

    public function messages()
    {
        return [
            'name.required' => 'Bạn chưa nhập họ tên',
            'name.min' => 'Tên phải có ít nhất 6 kí tự',
            'email.required' => 'Bạn chưa nhập email',
            'password.required' => 'Bạn chưa nhập mật khẩu',
            'password.confirmed' => 'Xác nhận mật khẩu không chính xác',
            'password.min' => 'Mật khẩu phải từ 8 kí tự',
            'birthday.required' => 'Bạn chưa chọn ngày sinh',
            'phone_number.required' => 'Bạn chưa nhập số điện thoại',
            'address.required' => 'Bạn chưa nhập địa chỉ',
            'image.required' => 'Bạn chưa chọn ảnh đại diện',
            'image.image' => 'Bạn cần chọn ảnh đại diện là hình ảnh',
            'image.mimes' => 'Hình đại diện phải có đuôi .jpeg,png,jpg,gif,svg',
            'image.max' => 'Dung lượng ảnh đại diện không vượt quá 2048',
            'id_card.required' => 'Bạn chưa nhập số CMND',
            'date_card.required' => 'Bạn chưa chọn ngày cấp CMND',
            'place_card.required' => 'Bạn chưa nhập nơi cấp CMND'
        ];
    }
}
