<?php

namespace App\Http\Controllers;

use App\Http\Requests\RecipientRequest;
use App\Recipient;
use App\User;
use Illuminate\Http\Request;

class RecipientsController extends Controller
{

    public function index(Request $request)
    {

        $users = User::select('*');

        if($request->key_word){
            $users->where(function ($users) use ($request) {
                $users->where('name', 'like', '%' . $request->key_word . '%')
                    ->orWhere('email', '=', '%' . $request->key_word . '%');
            });
        }

        if($request->role){
            $users->where('role', '=', 'recipient');
        }


        $users = $users->get();
        $request = $request->all();
        return view('recipients.list', compact('users', 'request'));

    }


    public function create()
    {
         return view('recipients.create');
    }


    public function store(RecipientRequest $request)
    {
        $data = $request->all();

        Recipient::create($data);


        return redirect('/recipients/list')->with('success', 'Lưu thông tin người nhận thành công');
    }


    public function show($id)
    {
        $data = Recipient::orderBy('id', 'asc')->paginate(10);
        return view('recipients.list', compact('data'));
    }


    public function edit($id)
    {
        $data = Recipient::find($id);
        return view('recipients.edit',compact(['data']))->with('recipients', $data);
    }


    public function update(Request $request, $id)
    {
        $data = Recipient::find($id);

        $data->name = $request->name;
        $data->birthday = $request->birthday;
        $data->phone_number = $request->phone_number;
        $data->address = $request->address;
        $data->town = $request->town;
        $data->district = $request->district;
        $data->city = $request->city;
        $data->id_card = $request->id_card;
        $data->date_card = $request->date_card;
        $data->place_card = $request->place_card;
        $data->money = $request->money;
        $data->currency = $request->currency;
        $data->save();

        return redirect('/recipients/list')->with('success', 'Cập nhật thành công');
    }


    public function destroy($id)
    {
        $data = Recipient::find($id);
        $data->delete();
        return redirect('/recipients/list')->with('success', 'Xóa người nhận thành công');
    }
}
