<?php

namespace App\Http\Controllers;

use App\AreaModel;
use App\DistrictModel;
use App\Http\Requests\UserRequest;
use App\MoneyModel;
use App\ProvinceModel;
use App\Trading;
use App\WardModel;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;


class UsersController extends Controller
{


    public function index(Request $request)
    {


        $users = User::select('*');

        if($request->key_word){
            $users->where(function ($users) use ($request) {
                $users->where('name', 'like', '%' . $request->key_word . '%')
                    ->orWhere('email', '=', '%' . $request->key_word . '%');
            });
        }

        if($request->role){
            $users->where('role', '=', $request->role);
        }


        $users = $users->paginate(10);
        $request = $request->all();
        return view('users.list', compact('users', 'request'));
    }


    public function create()
    {
        $province = ProvinceModel::pluck('name', 'provinceid')->prepend('Chọn tỉnh thành', '');
        return view('users.create', compact('province'));
    }

    public function store(UserRequest $request)
    {
        $users = $request->all();
        if($request->file('image')){
            $imageName = time() . '.' . $request->file('image')->getClientOriginalExtension();
            $users['image'] = $imageName;
            $request->file('image')->move(public_path('images'), $imageName);
        }else{
            $users['image'] = '';
        }

        if($request->password){
            $users['password'] = bcrypt($request->password);
        }else{
            $users['password'] = '';
        }
        User::create($users);


        return redirect('/users')->with('success', 'Tạo người dùng thành công');

    }

    public function show($id)
    {
        $users = User::find($id);

        return view('users.views', compact('users'));
//        $users = User::orderBy('id', 'asc')->paginate(10);
//        return view('users.list', compact('users'));
    }


    public function edit($id)
    {
        $users = User::find($id);
        $province = ProvinceModel::pluck('name', 'provinceid')->prepend('Chọn tỉnh thành', '');
        $district = [];
        $ward = [];
        if($users->province){
            $district = DistrictModel::pluck('name', 'districtid')->prepend('Chọn quận huyện', '');
        }

        if($users->district){
            $ward = WardModel::pluck('name', 'wardid')->prepend('Chọn phường xã', '');
        }
        return view('users.edit', compact('users', 'province', 'district', 'ward'));
    }


    public function view($id){
        $users = User::find($id);
        return view('users.views')->with('users', $users);
    }
    public function update(Request $request, $id)
    {

        $request->validate([
            'name' => 'required|min:6',
            'email' => 'required',
            'birthday' => 'required',
            'phone_number' => 'required',
            'address' => 'required',
            'id_card' => 'required',
            'date_card' => 'required',
            'place_card' => 'required'
        ]);


        $users = User::find($id);
        $users->role = $request->role;
        $users->name = $request->name;
        $users->email = $request->email;
        if($request->password){
            $users->password = bcrypt($request->password);
        }
        $users->birthday = $request->birthday;
        $users->phone_number = $request->phone_number;
        $users->province = $request->province;
        $users->district = $request->district;
        $users->ward = $request->ward;
        $users->address = $request->address;
        // $users->image = $request->image;
        $users->id_card = $request->id_card;
        $users->date_card = $request->date_card;
        $users->place_card = $request->place_card;
        $users->save();

        return redirect('/users')->with('success', 'Cập nhật thành công');
    }


    public function destroy($id)
    {
        $users = User::find($id);
        $users->delete();
        return redirect('/users/list')->with('success', 'Xóa thành công');
    }

    public function manager_list(Request $request){
        $province = ProvinceModel::pluck('name','provinceid')->prepend('Chọn tỉnh thành', '');
        $where = [];
        $data = [];
        if($request->month){
            $where[] = ['month', $request->month];
        }
        if($request->year){
            $where[] = ['year', $request->year];;
        }

        if($request->status){
            $where[] = ['status', $request->status];;
        }
        if($request->keyword){
            $where[] = ['name', $request->keyword];
        }
        if($request->province){
            $where[] = ['users.province', $request->province];
        }

        if($request->district){
            $where[] = ['users.district', $request->district];
        }

        if($request->ward){
            $where[] = ['users.ward', $request->ward];
        }



        $data = Trading::select('*', 'tradings.id','nhanvien.name as nhanvien','users.name as users_name', 'province.name as province_name', 'district.name as district_name', 'ward.name as ward_name')
			->leftJoin('users as nhanvien', 'nhanvien.id', '=', 'tradings.id_employee')
			->leftJoin('users', 'users.id', '=', 'tradings.user_id')
            ->leftJoin('province', 'province.provinceid', '=', 'users.province')
            ->leftJoin('district', 'district.districtid', '=', 'users.district')
            ->leftJoin('ward', 'ward.wardid', '=', 'users.ward')
            ->where($where)
            ->get();
			
			//foreach($data as $key=>$d){
			//	$data[$key]->nhanvien = User::find($d->id_employee)->name;
			//}
        return view('manager.index', compact('data', 'province'));
    }

    public function manager_create(){
        return view('manager.create');
    }

    public function manager_store(Request $request){
        $money = MoneyModel::all();
        foreach ($money as $m){
            Trading::create([
                'user_id' => $m->user_id,
                'money' => $m->money,
                'month' => $request->month,
                'year' => $request->year,
                'type' => $m->type
            ]);
        }
        return redirect('manager')->with('success', 'Tạo lệnh giao tiền thành công');;
    }
	
	public function manager_delete($id){
        Trading::find($id)->delete();
        return redirect('manager')->with('success', 'Xóa lệnh giao tiền thành công');;
    }

    public function money_list(Request $request){

        $province = ProvinceModel::pluck('name', 'provinceid')->prepend('Chọn tỉnh thành', '');
        $district = [];
        $ward = [];
        $where = [];
        if($request->province){
            $where[] = ['province', $request->province];
            $district = DistrictModel::where('provinceid', $request->province)->pluck('name', 'districtid')->prepend('Chọn quận huyện', '');
        }
        if($request->district){
            $where[] = ['district', $request->district];
            $ward = WardModel::where('districtid', $request->district)->pluck('name', 'wardid')->prepend('Chọn phường xã', '');
        }
        if($request->ward){
            $where[] = ['ward', $request->ward];
        }
        if($request->key_word){
            $where[] = ['users.name', 'like', '%'.$request->key_word.'%'];
        }
        $data = MoneyModel::select('*', 'money.id', 'province.name as province_name', 'district.name as district_name', 'ward.name as ward_name')
            ->where($where)
            ->leftJoin('users', 'users.id', '=', 'money.user_id')
            ->leftJoin('province', 'province.provinceid', '=', 'province')
            ->leftJoin('district', 'district.districtid', '=', 'district')
            ->leftJoin('ward', 'ward.wardid', '=', 'ward')
            ->orderby('money.id', 'desc')->get();
        $request = $request->all();
        $user = User::where('role', 'recipient')->pluck('name', 'id')->prepend('Chọn người nhận tiền', '');

        return view('money.index', compact('data', 'request', 'user', 'province', 'district', 'ward'));
    }

    public function money_create(){
        $user = User::where('role', 'recipient')->pluck('name', 'id')->prepend('Chọn người nhận tiền', '');
        return view('money.create', compact('user'));
    }

    public function money_store(Request $request){
        MoneyModel::create($request->all());
        return redirect(route('money.index'))->with('success', 'Thêm người nhận số tiền thành công');
    }

    public function money_delete($id){
        MoneyModel::find($id)->delete();
        return redirect(route('money.index'))->with('success', 'Xóa người nhận số tiền thành công');
    }


    public function area_list(Request $request){
        $district = [];
        $ward = [];
        $province = ProvinceModel::pluck('name', 'provinceid')->prepend('Chọn tỉnh thành', '');
        $where = [];
        if($request->province){
            $where[] = ['province_id', $request->province];
            $district = DistrictModel::where('provinceid', $request->province)->pluck('name', 'districtid')->prepend('Chọn quận huyện', '');
        }
        if($request->district){
            $where[] = ['district_id', $request->district];
            $ward = WardModel::where('districtid', $request->district)->pluck('name', 'wardid')->prepend('Chọn phường xã', '');
        }
        if($request->ward){
            $where[] = ['ward_id', $request->ward];
        }

        if($request->user){
            $where[] = ['users.id', $request->user];
        }
        $data = AreaModel::select('*','users.name', 'province.name as province_name', 'district.name as district_name', 'ward.name as ward_name')
            ->where($where)
            ->leftJoin('users', 'users.id', '=', 'user_id')
            ->leftJoin('province', 'province.provinceid', '=', 'area.province_id')
            ->leftJoin('district', 'district.districtid', '=', 'area.district_id')
            ->leftJoin('ward', 'ward.wardid', '=', 'area.ward_id')
            ->orderby('area_id', 'desc')->get();

        $request = $request->all();
        $user = User::where('role', 'employee')->pluck('name', 'id')->prepend('Tất cả nhân viên giao tiền', '');

        return view('area.index', compact('data', 'request', 'user', 'province', 'district', 'ward'));
    }

    public function area_store(Request $request){
        AreaModel::create([
            'user_id' => $request->user_id,
            'province_id' => $request->province,
            'district_id' => $request->district,
            'ward_id' => $request->ward,
        ]);


        return redirect(route('area.index'))->with('success', 'Thêm thành công');

    }

    public function area_delete($id){
        AreaModel::find($id)->delete();
        return redirect(route('area.index'))->with('success', 'Xóa thành công');
    }

    public function user_import(Request $request){

        $objPHPExcel = \PHPExcel_IOFactory::load($request->file('file')); // load file ra object PHPExcel
        $dataSheet = $objPHPExcel->setActiveSheetIndex(0); // Set sheet sẽ được đọc dữ liệu
        $highestRow    = $dataSheet->getHighestRow(); // Lấy số row lớn nhất trong sheet
        if($highestRow < 6){
            return redirect('/users')->with('success', 'Tạo người dùng thành công');
        }
        for ($row = 6; $row <= $highestRow; $row++) {

            $check = User::where('email', $dataSheet->getCellByColumnAndRow(3, $row)->getValue())->first();
            if($check){
                return redirect('/users')->with('success', $dataSheet->getCellByColumnAndRow(3, $row)->getValue(). ' đã tồn tại');
            }

            $users = [
                'role' => $dataSheet->getCellByColumnAndRow(1, $row)->getValue(),
                'name' => $dataSheet->getCellByColumnAndRow(2, $row)->getValue(),
                'email' => $dataSheet->getCellByColumnAndRow(3, $row)->getValue(),
                'phone_number' => $dataSheet->getCellByColumnAndRow(4, $row)->getValue(),
                'birthday' => $dataSheet->getCellByColumnAndRow(5, $row)->getValue(),
                'id_card' => $dataSheet->getCellByColumnAndRow(6, $row)->getValue(),
                'date_card' => $dataSheet->getCellByColumnAndRow(7, $row)->getValue(),
                'place_card' => $dataSheet->getCellByColumnAndRow(8, $row)->getValue(),
                'image' => ''
            ];

            if($dataSheet->getCellByColumnAndRow(9, $row)->getValue()) {
                $users['password'] = bcrypt($dataSheet->getCellByColumnAndRow(9, $row)->getValue());
            }else{
                $users['password'] = '';
            }

            User::create($users);
        }





        return redirect('/users')->with('success', 'Tạo người dùng thành công');

    }

}
