<?php

namespace App\Http\Controllers;

use App\AreaModel;
use App\DistrictModel;
use App\ProvinceModel;
use App\Trading;
use App\User;
use App\WardModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ApiController extends Controller
{

    public function index()
    {
        return view('home');
    }

    public function province(){
        return ['status' => 'success', 'data' => ProvinceModel::all()];
    }

    public function district($id){
        return ['status' => 'success', 'data' => DistrictModel::where('provinceid', $id)->get()];
    }

    public function ward($id){
        return ['status' => 'success', 'data' => WardModel::where('districtid', $id)->get()];
    }

    public function change_password(Request $request){
        $data = User::find($request->user_id);
        if(!$data){
            return ['status' => false, 'message' => ['Không tìm thấy tài khoản']];
        }

        if(!Hash::check($request->password_old,$data->password)){
            return ['status' => false, 'message' => ['Sai mật khẩu cũ']];
        }else{
            $data->password = bcrypt($request->password_new);
            $data->save();
            return ['status' => 'success', 'data' => $data];
        }

    }

    public function login(Request $request){
        $data = User::where('email', $request->email)->where('role', '<>', 'recipient')->first();
        if(!$data){
            return ['status' => false, 'message' => ['Sai tài khoản hoặc mật khẩu']];
        }

        if(!Hash::check($request->password,$data->password)){
            return ['status' => false, 'message' => ['Sai tài khoản hoặc mật khẩu']];
        }

        return ['status' => 'success', 'data' => $data];
    }

    public function money_list(Request $request){
//        $where = [];
//        if($request->month){
//            $where[] = ['month', $request->month];
//        }
//        if($request->year){
//            $where[] = ['year', $request->year];;
//        }
//        if($request->keyword){
//            $where[] = ['users.name', 'like','%'.$request->keyword.'%'];
//        }
//        if($request->province){
//            $where[] = ['users.province', $request->province];
//        }
//        if($request->district){
//            $where[] = ['users.district', $request->district];
//        }
//        if($request->ward){
//            $where[] = ['users.ward', $request->ward];
//        }

        $province = AreaModel::select('province_id')->where('user_id', $request->user_id)->get()->toArray();
        $district = AreaModel::select('district_id')->where('user_id', $request->user_id)->get()->toArray();
        $ward = AreaModel::select('ward_id')->where('user_id', $request->user_id)->get()->toArray();


        $data = Trading::select('*', 'tradings.id', 'users.name as users_name', 'province.name as province_name', 'district.name as district_name', 'ward.name as ward_name')
            ->where('status','not received')
            ->leftJoin('users', 'users.id', '=', 'tradings.user_id')
            ->leftJoin('province', 'province.provinceid', '=', 'province')
            ->leftJoin('district', 'district.districtid', '=', 'district')
            ->leftJoin('ward', 'ward.wardid', '=', 'ward')
            ->whereIn('province', $province);

        if($district){
            $data->orWhereIn('district', $district);
        }

        if($ward){
            $data->orWhereIn('ward', $ward);
        }



        return ['status' => 'success', 'data' => $data->get()];
    }

    public function money_detail($id){
        $data = Trading::select('*')
            ->where('tradings.id', $id)
            ->first();

        $list = Trading::select('*')
            ->where('user_id', '=', $data->user_id)
            ->get();


        return ['status' => 'success', 'data' => $data, 'list' => $list];
    }

    public function money_check($user_id, $id, $password){

        $check = Trading::select('*')
            ->where('tradings.id', $id)
            ->leftJoin('users', 'users.id', '=', 'tradings.user_id')->first();
        if($check){
            if(Hash::check($password,$check->password)){
                Trading::where('id', $id)->update([
                    'id_employee' => $user_id,
                    'date_confirm' => date_create(),
                    'status' => 'received'
                ]);
                return ['status' => 'success'];
            }else{
                return ['status' => false, 'message' => ['Mã bảo mật không đúng']];
            }
        }else{
            return ['status' => false, 'message' => ['Mã QR-code không đúng']];
        }
    }

    public function money_status($id, $user_id){
        Trading::where('id', $id)->update([
            'id_employee' => $user_id,
            'date_confirm' => date_create(),
            'status' => 'received'
        ]);

        return ['status' => 'success'];
    }
}
