<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TradingsController extends Controller
{

    public function index()
    {

    }


    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }


    public function show()
    {
        return view('tradings.settlement');
        return view('tradings.payment');
    }


    public function edit($id)
    {

    }


    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        //
    }
}
