<?php

namespace App\Http\Controllers;

use App\DistrictModel;
use App\ProvinceModel;
use App\WardModel;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function province(){
        return ProvinceModel::all();
    }

    public function district($id){
        return DistrictModel::where('provinceid', $id)->get();
    }

    public function ward($id){
        return WardModel::where('districtid', $id)->get();
    }
}
