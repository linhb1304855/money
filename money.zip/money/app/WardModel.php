<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WardModel extends Model
{
    protected $table = 'ward';
    protected $primaryKey = 'wardid';
    protected $fillable = ['name', 'districtid'];
    protected $keyType = 'varchar';
}
