<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MoneyModel extends Model
{
    protected $table = 'money';
    protected $primaryKey = 'id';
    protected $fillable = ['user_id', 'money', 'type'];
    protected $keyType = 'varchar';
}
