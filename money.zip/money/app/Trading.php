<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trading extends Model
{
    protected $table = 'tradings';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id',
        'user_id',
        'money',
        'id_employee',
        'date_confirm',
        'status',
        'month',
        'year','type'
    ];
}
