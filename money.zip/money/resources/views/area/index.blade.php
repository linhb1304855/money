@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="#" style="margin-bottom: 10px;"  data-toggle="modal" data-target="#exampleModal" class="btn btn-primary">Thêm mới</a>

                {{ Form::open(['url' => route('area.index'), 'method' => 'get' ]) }}
                <div class="row">
                    <div class="col-md-3">
                        {!! Form::select('user',$user  ,isset($request['user']) ? $request['user'] : '',['id'=>'user','class'=>'form-control']) !!}
                    </div>
                    <div class="col-md-2">
                        {!! Form::select('province',$province  ,isset($request['province']) ? $request['province'] : '',['id'=>'province','class'=>'form-control']) !!}
                    </div>
                    <div class="col-md-2">
                        {!! Form::select('district',$district  ,isset($request['district']) ? $request['district'] : '',['id'=>'district','class'=>'form-control']) !!}
                    </div>
                    <div class="col-md-2">
                        {!! Form::select('ward',$ward  ,isset($request['ward']) ? $request['ward'] : '',['id'=>'ward','class'=>'form-control']) !!}
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-info">Tìm kiếm</button>
                    </div>
                </div>
                {!!Form::close()!!}
                <br/>
                <div class="card-header"><h3 style="text-align: center">QUẢN LÝ KHU VỰC GIAO TIỀN</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th style="text-align: center">#</th>
                                <th>Họ Tên</th>
                                <th>Tỉnh thành</th>
                                <th>Quận huyện</th>
                                <th>Phường xã</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($data as $key=>$value)
                                <tr>
                                    <td style="text-align: center">{{$key+1}}</td>
                                    <td>{{$value->name}}</td>
                                    <td>{{$value->province_name}}</td>
                                    <td>{{$value->district_name}}</td>
                                    <td>{{$value->ward_name}}</td>
                                    <td>
                                        <a class="btn btn-primary" onclick="return confirm('Bạn có chắc muốn xóa dòng này ?');" href="{{route('area.delete', $value->area_id)}}">Xóa</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <div class="modal" tabindex="-1" role="dialog" id="exampleModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('area.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ]) }}
                <div class="modal-header">
                    <h5 class="modal-title">PHÂN KHU VỰC GIAO TIỀN CHO NHÂN VIÊN</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="formGroupExampleInput2">Chọn nhân viên</label>
                                {!! Form::select('user_id',$user  ,old('user', ''),['id'=>'user','class'=>'form-control','required']) !!}
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label for="formGroupExampleInput2">Tỉnh thành</label>
                            <div class="form-group">
                                {!! Form::select('province',$province  ,'',['id'=>'province_create','class'=>'form-control','required'=>'required']) !!}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="formGroupExampleInput2">Quận huyện</label>
                            <div class="form-group">
                                {!! Form::select('district',[]  ,'',['id'=>'district_create','class'=>'form-control']) !!}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="formGroupExampleInput2">Phường xã</label>
                            <div class="form-group">
                                {!! Form::select('ward',[]  ,'',['id'=>'ward_create', 'class'=>'form-control']) !!}
                            </div>
                        </div>
                    </div>
                    <div class="row">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-primary">Thêm</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>

    <script>
        var province = '';

        $('#province').change(function (value) {
            $.ajax({
                url : "/money/public/district/" + $('#province').val(),
                type : "get",
                success : function (data){
                    var district = $('#district');
                    console.log(data);
                    district.empty();
                    $('#ward').empty();
                    district.append('<option value="">Chọn Quận Huyện</option>');
                    for (var i = 0; i < data.length; i++) {
                        district.append('<option value=' + data[i].districtid + '>' + data[i].name + '</option>');
                    }
                    district.change();
                }
            });
        });

        $('#district').change(function (value) {
            $.ajax({
                url : "/money/public/ward/" + $('#district').val(),
                type : "get",
                success : function (data){
                    var ward = $('#ward');
                    ward.empty();
                    ward.append('<option value="">Chọn Phường Xã</option>');
                    for (var i = 0; i < data.length; i++) {
                        ward.append('<option value=' + data[i].wardid + '>' + data[i].name + '</option>');
                    }
                    ward.change();
                }
            });
        });




        $('#province_create').change(function (value) {
            $.ajax({
                url : "/money/public/district/" + $('#province_create').val(),
                type : "get",
                success : function (data){
                    var district = $('#district_create');
                    console.log(data);
                    district.empty();
                    $('#ward_create').empty();
                    district.append('<option value="">Chọn Quận Huyện</option>');
                    for (var i = 0; i < data.length; i++) {
                        district.append('<option value=' + data[i].districtid + '>' + data[i].name + '</option>');
                    }
                    district.change();
                }
            });
        });

        $('#district_create').change(function (value) {
            $.ajax({
                url : "/money/public/ward/" + $('#district_create').val(),
                type : "get",
                success : function (data){
                    var ward = $('#ward_create');
                    ward.empty();
                    ward.append('<option value="">Chọn Phường Xã</option>');
                    for (var i = 0; i < data.length; i++) {
                        ward.append('<option value=' + data[i].wardid + '>' + data[i].name + '</option>');
                    }
                    ward.change();
                }
            });
        });


        var loadFile = function(event) {
            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('output');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        };
    </script>
@endsection

