@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h2>TẠO LỆNH GIAO TIỀN THEO THÁNG</h2></div>
                    <div class="card-body">
                        {{ Form::open(['url' => route('manager.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ]) }}
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Tháng</label>
                                    <select class="form-control" required name="month">
                                        <option name="key_word_role" value="">-- Chọn tháng --</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>6</option>
                                        <option>7</option>
                                        <option>8</option>
                                        <option>9</option>
                                        <option>10</option>
                                        <option>11</option>
                                        <option>12</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="formGroupExampleInput2">Năm</label>
                                <div class="form-group">
                                    <select class="form-control" required name="year">
                                        <option name="key_word_role" value="">-- Chọn năm --</option>
                                        <option>2019</option>
                                        <option>2020</option>
                                        <option>2021</option>
                                        <option>2022</option>
                                        <option>2023</option>
                                        <option>2024</option>
                                        <option>2025</option>
                                        <option>2026</option>
                                        <option>2027</option>
                                        <option>2028</option>
                                        <option>2029</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <button type="submit" class="btn btn-primary">Xác nhận</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection