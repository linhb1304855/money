@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h2>TẠO NGƯỜI DÙNG</h2></div>
                    <div class="card-body">
                        {{ Form::open(['url' => route('users.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ]) }}

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Loại người dùng</label>
                                    <select class="form-control" name="role">
                                        <option value="admin">Quản trị</option>
                                        <option value="employee">Nhân viên</option>
                                        <option value="recipient">Người nhận</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Tên người dùng</label>
                                    <input type="text" class="form-control" name="name" value="{{old('name')}}">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput">Email</label>
                                    <input type="text" class="form-control" name="email" value="{{old('email')}}" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Số điện thoại</label>
                                    <input type="text" class="form-control" name="phone_number" value="{{old('phone_number')}}" >
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Mật khẩu</label>
                                    <input type="password" class="form-control" name="password" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Xác nhận lại mật khẩu</label>
                                    <input type="password" class="form-control" name="password_confirmation" >
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Tỉnh thành</label>
                                    {!! Form::select('province',$province  ,old('province', ''),['id'=>'province','class'=>'form-control','required'=>'required']) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Quận huyện</label>
                                    {!! Form::select('district',[]  ,old('district', ''),['id'=>'district','class'=>'form-control','required'=>'required']) !!}
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Phường xã</label>
                                    {!! Form::select('ward',[]  ,old('ward', ''),['id'=>'ward', 'class'=>'form-control','required'=>'required']) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Địa chỉ</label>
                                    <input type="text" class="form-control" name="address" value="{{old('address')}}" >
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Số Chứng minh nhân dân</label>
                                    <input type="text" class="form-control" name="id_card" value="{{old('id_card')}}" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Ngày cấp CMND</label>
                                    <input type="date" class="form-control" name="date_card" value="{{old('date_card')}}">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Ngày sinh</label>
                                    <input type="date" class="form-control" name="birthday" value="{{old('birthday')}}" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Nơi cấp CMND</label>
                                    <input type="text" class="form-control" name="place_card" value="{{old('place_card')}}" >
                                </div>
                            </div>
                        </div>











                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ảnh người dùng</label>
                            <input type="file" accept="image/*" onchange="loadFile(event)" name="image" class="form-control">
                            <img id="output" style="width: 200px; height: 200px; margin-top: 10px"/>
                            <script>
                                var province = '';

                                $('#province').change(function (value) {
                                    $.ajax({
                                        url : "/money/public/district/" + $('#province').val(),
                                        type : "get",
                                        success : function (data){
                                            var district = $('#district');
                                            console.log(data);
                                            district.empty();
                                            $('#ward').empty();
                                            district.append('<option value="">Chọn Quận Huyện</option>');
                                            for (var i = 0; i < data.length; i++) {
                                                district.append('<option value=' + data[i].districtid + '>' + data[i].name + '</option>');
                                            }
                                            district.change();
                                        }
                                    });
                                });

                                $('#district').change(function (value) {
                                    $.ajax({
                                        url : "/money/public/ward/" + $('#district').val(),
                                        type : "get",
                                        success : function (data){
                                            var ward = $('#ward');
                                            ward.empty();
                                            ward.append('<option value="">Chọn Phường Xã</option>');
                                            for (var i = 0; i < data.length; i++) {
                                                ward.append('<option value=' + data[i].wardid + '>' + data[i].name + '</option>');
                                            }
                                            ward.change();
                                        }
                                    });
                                });


                                var loadFile = function(event) {
                                    var reader = new FileReader();
                                    reader.onload = function(){
                                        var output = document.getElementById('output');
                                        output.src = reader.result;
                                    };
                                    reader.readAsDataURL(event.target.files[0]);
                                };
                            </script>
                        </div>




                        <button type="submit" class="btn btn-primary">Tạo tài khoản</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection