@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="{{route('users.create')}}" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người dùng</a>
                <a href="#" style="margin-bottom: 10px;"  data-toggle="modal" data-target="#exampleModal" class="btn btn-success">Import</a>

                {{ Form::open(['url' => route('users.index'), 'method' => 'get' ]) }}
                    <div class="row">
                        <div class="col-md-3">
                            <input type="text" value="{{isset($request['key_word']) ? $request['key_word'] : ''}}" class="form-control" name="key_word" placeholder="Nhập tên hoặc email...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" name="role">
                                <option name="key_word_role" value="">-- Tất cả loại tài khoản--</option>
                                <option name="key_word_role" {{isset($request['role']) && $request['role'] == 'admin' ? 'selected' : ''}} value="admin">Quản trị</option>
                                <option name="key_word_role" {{isset($request['role']) && $request['role'] == 'employee' ? 'selected' : ''}} value="employee">Nhân viên giao tiền</option>
                                <option name="key_word_role" {{isset($request['role']) && $request['role'] == 'recipient' ? 'selected' : ''}} value="recipient">Người nhận tiền</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-info">Tìm kiếm</button>
                        </div>
                    </div>
                {!!Form::close()!!}

                <div class="card-header"><h3 style="text-align: center">QUẢN LÝ NGƯỜI DÙNG</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th style="text-align: center">#</th>
                                <th>Họ Tên</th>
                                <th>Email</th>
                                <th>Loại tài khoản</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $key=>$user)
                                <tr>
                                    <th scope="row" style="text-align: center">
                                        @if(\Illuminate\Support\Facades\Input::get('page') <= 1)
                                            {{$key+1}}
                                        @else
                                            {{$key+((\Illuminate\Support\Facades\Input::get('page')-1)*10 + 1)}}
                                        @endif
                                    </th>
                                    <td>
                                        <img src="{{$user->image ? url('images') . '/' . $user->image : 'https://cdn.iconscout.com/icon/free/png-256/avatar-380-456332.png'}}"  style="width: 30px; height: 30px; object-fit: cover"/>
                                        {{$user->name}}
                                    </td>
                                    <td>
                                        {{$user->phone_number}}
                                        <br/>
                                        {{$user->email}}
                                    </td>
                                    <td>
                                        @if($user->role == 'admin')
                                        <span class="badge badge-warning" style="color:#fff;">Admin</span>
                                        @endif
                                        @if($user->role == 'employee')
                                        <span class="badge badge-info">Nhân viên</span>
                                        @endif
                                        @if($user->role == 'recipient')
                                        <span class="badge badge-primary">Người nhận tiền</span>
                                        @endif
                                    </td>
                                    <td>
{{--                                        <a href="{{url('users/'.$user->id)}}" style="margin-bottom: 10px;" class="btn btn-primary">Xem</a>--}}
                                        <a  href="{{url('users/'.$user->id.'/edit')}}" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                        {!!Form::open(['action' => ['UsersController@destroy', $user->id], 'method' => 'POTS', 'class' => 'pull-right'])!!}
                                        {{Form::hidden('_method', 'DELETE')}}
                                        {{Form::submit('Xóa', ['class' => 'btn btn-danger'])}}
                                        {!!Form::close()!!}

                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $users->appends(request()->input())->links(); !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <div class="modal" tabindex="-1" role="dialog" id="exampleModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('import'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ]) }}
                <div class="modal-header">
                    <h5 class="modal-title">Download mẫu import <a href="{{asset('assets/import_user.xlsx')}}" target="_blank">tại đây</a></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="formGroupExampleInput2">File Import</label>
                                <input type="file" class="form-control" name="file" />
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
@endsection