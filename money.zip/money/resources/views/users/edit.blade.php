@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h3>CẬP NHẬT TÀI KHOẢN</h3></div>
                    <div class="card-body">
                        {{ Form::open(['url' => route('users.update', $users->id), 'method' => 'POST', 'enctype' => 'multipart/form-data' ]) }}
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            {{Form::label('role', 'Loại người dùng')}}
                            <select class="form-control" name="role" >
                                @if($users->role =="admin")
                                    <option value="admin" selected="selected">Quản trị</option>
                                    <option value="employee">Nhân viên</option>
                                    <option value="recipient" >Người nhận tiền</option>
                                @elseif($users->role =="employee")
                                    <option value="admin" >Quản trị</option>
                                    <option value="employee" selected="selected">Nhân viên</option>
                                    <option value="recipient" >Người nhận tiền</option>
                                @else
                                    <option value="admin" >Quản trị</option>
                                    <option value="employee" >Nhân viên</option>
                                    <option value="recipient" selected="selected" >Người nhận tiền</option>
                                @endif
                            </select>
                        </div>

                        <div class="form-group">
                            {{Form::label('name', 'Tên người dùng')}}
                            {{Form::text('name', $users->name, ['class' => 'form-control', 'placeholder' => 'Tên người dùng'])}}

                        </div>

                        <div class="form-group">
                            {{Form::label('email', 'Email')}}
                            {{Form::text('email', $users->email, ['class' => 'form-control', 'placeholder' => 'Email'])}}
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Mật khẩu</label>
                                    <input type="password" class="form-control" name="password" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Xác nhận lại mật khẩu</label>
                                    <input type="password" class="form-control" name="password_confirmation" >
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            {{Form::label('birthday', 'Ngày sinh')}}
                            {{Form::date('birthday', $users->birthday, ['class' => 'form-control', 'placeholder' => 'Ngày sinh'])}}
                        </div>
                        <div class="form-group">
                            {{Form::label('phone_number', 'Số điện thoại')}}
                            {{Form::text('phone_number', $users->phone_number, ['class' => 'form-control', 'placeholder' => 'Số điện thoại'])}}
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Tỉnh thành</label>
                                    {!! Form::select('province',$province  ,$users->province,['id'=>'province','class'=>'form-control','required'=>'required']) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Quận huyện</label>
                                    {!! Form::select('district',$district  ,$users->district,['id'=>'district','class'=>'form-control','required'=>'required']) !!}
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Phường xã</label>
                                    {!! Form::select('ward',$ward  ,$users->ward,['id'=>'ward', 'class'=>'form-control','required'=>'required']) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="formGroupExampleInput2">Địa chỉ</label>
                                    {{Form::text('address', $users->address, ['class' => 'form-control', 'placeholder' => 'Địa chỉ'])}}
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ảnh người dùng</label>

                            <img src="{{url('images') . '/' . $users->image}}" id="output" style="width: 100px; height: 100px"/>
                        </div>
                        <div class="form-group">
                            {{Form::label('id_card', 'Số chứng minh nhân dân')}}
                            {{Form::text('id_card', $users->id_card, ['class' => 'form-control', 'placeholder' => 'So CMND'])}}
                        </div>
                        <div class="form-group">
                            {{Form::label('date_card', 'Ngày cấp CMND')}}
                            {{Form::date('date_card', $users->date_card, ['class' => 'form-control', 'placeholder' => 'Ngày cấp CMND'])}}
                        </div>
                        <div class="form-group">
                            {{Form::label('place_card', 'Nơi cấp CMND')}}
                            {{Form::text('place_card', $users->place_card, ['class' => 'form-control', 'placeholder' => 'Nơi cấp CMND'])}}
                        </div>
                        <script>
                            var province = '';

                            $('#province').change(function (value) {
                                $.ajax({
                                    url : "/money/public/district/" + $('#province').val(),
                                    type : "get",
                                    success : function (data){
                                        var district = $('#district');
                                        console.log(data);
                                        district.empty();
                                        $('#ward').empty();
                                        district.append('<option value="">Chọn Quận Huyện</option>');
                                        for (var i = 0; i < data.length; i++) {
                                            district.append('<option value=' + data[i].districtid + '>' + data[i].name + '</option>');
                                        }
                                        district.change();
                                    }
                                });
                            });

                            $('#district').change(function (value) {
                                $.ajax({
                                    url : "/money/public/ward/" + $('#district').val(),
                                    type : "get",
                                    success : function (data){
                                        var ward = $('#ward');
                                        ward.empty();
                                        ward.append('<option value="">Chọn Phường Xã</option>');
                                        for (var i = 0; i < data.length; i++) {
                                            ward.append('<option value=' + data[i].wardid + '>' + data[i].name + '</option>');
                                        }
                                        ward.change();
                                    }
                                });
                            });


                            var loadFile = function(event) {
                                var reader = new FileReader();
                                reader.onload = function(){
                                    var output = document.getElementById('output');
                                    output.src = reader.result;
                                };
                                reader.readAsDataURL(event.target.files[0]);
                            };
                        </script>
                        {{Form::hidden('_method', 'PUT')}}
                        {{Form::submit('Cập nhật tài khoản', ['class'=>'btn btn-primary'])}}
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection