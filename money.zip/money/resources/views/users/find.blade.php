@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="{{route('users.create')}}" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người dùng</a>
                <br>
                <div class="col-md-9">
                    <div class="alert alert-success">
                        <h4><b>Chi tiết</b></h4>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"><h2>QUẢN LÝ NGƯỜI DÙNG</h2></div>
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh đại diện</th>
                                <th scope="col">Loại người dùng</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Số điện thoại</th>
                                <th scope="col">Địa chỉ</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $key=>$user)
                                <tr>
                                    <th scope="row">{{$key+1}}</th>
                                    <td>
                                        <img src="{{url('images') . '/' . $user->image}}" id="output" style="width: 100px; height: 100px"/>
                                    </td>
                                    <td>{{$user->role}}</td>
                                    <td>{{$user->name}}</td>
                                    <td>{{$user->email}}</td>
                                    <td>{{$user->phone_number}}</td>
                                    <td>{{$user->address}}</td>
                                    <td>
                                        <a href="/usecase/public/users/{{$user->id}}/edit" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                        {!!Form::open(['action' => ['UsersController@destroy', $user->id], 'method' => 'USER', 'class' => 'pull-right'])!!}
                                        {{Form::hidden('_method', 'DELETE')}}
                                        {{Form::submit('Xóa', ['class' => 'btn btn-danger'])}}

                                        {!!Form::close()!!}

                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection