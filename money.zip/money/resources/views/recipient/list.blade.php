@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="{{route('users.create')}}" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người dùng</a>

                {{ Form::open(['url' => route('users.index'), 'method' => 'get' ]) }}
                    <div class="row">
                        <div class="col-md-3">
                            <input type="text" value="{{isset($request['key_word']) ? $request['key_word'] : ''}}" class="form-control" name="key_word" placeholder="Nhập tên hoặc email...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" name="role">
                                <option name="key_word_role" value="">-- Tất cả loại tài khoản--</option>
                                <option name="key_word_role" {{isset($request['role']) && $request['role'] == 'admin' ? 'selected' : ''}} value="admin">Quản trị</option>
                                <option name="key_word_role" {{isset($request['role']) && $request['role'] == 'employee' ? 'selected' : ''}} value="employee">Nhân viên giao tiền</option>
                                <option name="key_word_role" {{isset($request['role']) && $request['role'] == 'recipient' ? 'selected' : ''}} value="recipient">Người nhận tiền</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-info">Tìm kiếm</button>
                        </div>
                    </div>
                {!!Form::close()!!}

                <div class="card-header"><h3 style="text-align: center">QUẢN LÝ NGƯỜI DÙNG</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Họ Tên</th>
                                <th scope="col">Email</th>
                                <th scope="col">Loại tài khoản</th>quanlyvanban
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $key=>$user)
                                <tr>
                                    <th scope="row">{{$key+1}}</th>
                                    <td>
                                        <img src="{{url('images') . '/' . $user->image}}"  style="float:left;width: 50px; height: 50px; object-fit: cover"/>
                                        <p style="margin-bottom: -6px;margin-top: 7px;">{{$user->name}}</p>
                                    </td>
                                    <td>
                                        {{$user->phone_number}}
                                        <br/>
                                        {{$user->email}}
                                    </td>
                                    <td>
                                        @if($user->role == 'admin')
                                        <span class="badge badge-warning" style="color:#fff;">Admin</span>
                                        @endif
                                        @if($user->role == 'employee')
                                        <span class="badge badge-info">Nhân viên</span>
                                        @endif
                                        @if($user->role == 'recipient')
                                        <span class="badge badge-primary">Người nhận tiền</span>
                                        @endif
                                    </td>
                                    <td>
                                        <a  href="{{url('users/'.$user->id.'/edit')}}" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                        {!!Form::open(['action' => ['UsersController@destroy', $user->id], 'method' => 'POTS', 'class' => 'pull-right'])!!}
                                        {{Form::hidden('_method', 'DELETE')}}
                                        {{Form::submit('Xóa', ['class' => 'btn btn-danger'])}}
                                        {!!Form::close()!!}

                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection