@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <ul class="navbar-nav ml-auto">
                </ul>
                <div class="card-header"><h3 style="text-align: center">DANH SÁCH QUYẾT TOÁN</h3></div>
                <div class="card">

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Mã người nhận</th>
                                <th scope="col">Ngày nhận</th>
                                <th scope="col">Tháng nhận</th>
                                <th scope="col">Năm nhận</th>
                                <th scope="col">Thời gian nhận</th>
                                <th scope="col">Số tiền</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Ghi chú</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>1</td>
                                <td>nguoinhan1</td>
                                <td>20</td>
                                <td>06</td>
                                <td>2019</td>
                                <td>14:35</td>
                                <td>15.000.000</td>
                                <td>Nhận lệnh đi</td>
                                <td>Hẹn 16:00</td>
                            </tr>
                            </tbody>
                            <tbody>
                            <tr>
                                <td>2</td>
                                <td>nguoinhan2</td>
                                <td>21</td>
                                <td>06</td>
                                <td>2019</td>
                                <td>08:00</td>
                                <td>10.000.000</td>
                                <td>Đã nhận</td>
                                <td></td>
                            </tr>
                            </tbody>
                            <tbody>
                            <tr>
                                <td>3</td>
                                <td>nguoinhan3</td>
                                <td>22</td>
                                <td>06</td>
                                <td>2019</td>
                                <td>16:10</td>
                                <td>7.000.000</td>
                                <td>Nhận đi</td>
                                <td></td>
                            </tr>
                            </tbody>
                            <tbody>
                            <tr>
                                <td>4</td>
                                <td>nguoinhan4</td>
                                <td>22</td>
                                <td>06</td>
                                <td>2019</td>
                                <td>13:20</td>
                                <td>8.000.000</td>
                                <td>Gửi mã để nhận</td>
                                <td>Delay lấn 1</td>
                            </tr>
                            </tbody>
                            <tbody>
                            <tr>
                                <td>5</td>
                                <td>nguoinhan5</td>
                                <td>22</td>
                                <td>06</td>
                                <td>2019</td>
                                <td>14:35</td>
                                <td>10.000.000</td>
                                <td>Gửi mã để nhận</td>
                                <td></td>
                            </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection