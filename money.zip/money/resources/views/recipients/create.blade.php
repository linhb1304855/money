@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <a href="/usecase/public/recipients/list" style="margin-bottom: 10px;" class="btn btn-secondary">Go Back</a>
                <div class="card">
                    <div class="card-header"><h3>NHẬP THÔNG TIN NGƯỜI NHẬN</h3></div>
                    <div class="card-body">
                        {{ Form::open(['url' => route('recipients.store'), 'method' => 'POST', 'enctype' => 'multipart/form-data' ]) }}


                        <div class="form-group">
                            <label for="formGroupExampleInput2">Họ và tên người nhận</label>
                            <input type="text" class="form-control" name="name" value="{{old('name')}}">
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày sinh</label>
                            <input type="date" class="form-control" name="birthday" value="{{old('birthday')}}" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số điện thoại</label>
                            <input type="text" class="form-control" name="phone_number" value="{{old('phone_number')}}" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Địa chỉ</label>
                            <input type="text" class="form-control" name="address" value="{{old('address')}}" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Tỉnh-Thành phố</label>
                            <select class="form-control" name="city">
                                <option value="Cần Thơ">Cần Thơ</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="formGroupExampleInput2">Quận-Huyện</label>
                            <select class="form-control" name="district">
                                <option value="Cái Răng">Cái Răng</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Xã-Phường</label>
                            <select class="form-control" name="town">
                                <option value="Ba Láng">Ba Láng</option>
                                <option value="Hưng Phú">Hưng Phú</option>
                                <option value="Hưng Thạnh">Hưng Thạnh</option>
                                <option value="Lê Bình">Lê Bình</option>
                                <option value="Phú Thứ">Phú Thứ</option>
                                <option value="Tân Phú">Tân Phú</option>
                                <option value="Thường Thạnh">Thường Thạnh</option>
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số Chứng minh nhân dân</label>
                            <input type="text" class="form-control" name="id_card" value="{{old('id_card')}}" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Ngày cấp CMND</label>
                            <input type="date" class="form-control" name="date_card" value="{{old('date_card')}}">
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Nơi cấp CMND</label>
                            <input type="text" class="form-control" name="place_card" value="{{old('place_card')}}" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Số tiền</label>
                            <input type="text" class="form-control" name="money" value="{{old('money')}}" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Loại tiền</label>
                            <select class="form-control" name="currency">
                                <option value="Mẹ Việt Nam anh hùng">Mẹ Việt Nam anh hùng</option>
                                <option value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                                <option value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                                <option value="Thương binh">Thương binh</option>
                                <option value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>
                            </select>
                        </div>
                        <button type="submit">Lưu người nhận</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection