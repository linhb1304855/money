@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="{{route('recipients.create')}}" style="margin-bottom: 10px;" class="btn btn-primary">Thêm người nhận</a>

                {{ Form::open(['url' => route('recipients.index'), 'method' => 'get' ]) }}
                <div class="row">
                    <div class="col-md-3">
                        <input type="text" value="{{isset($request['key_word']) ? $request['key_word'] : ''}}" class="form-control" name="key_word" placeholder="Nhập họ tên...">
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="currency">
                            <option name="key_word" value="">-Loại tiền-</option>
                            <option name="key_word" {{isset($request['currency']) && $request['currency'] == 'Mẹ Việt Nam anh hùng' ? 'selected' : ''}} value="Mẹ Việt Nam anh hùng" >Mẹ Việt Nam anh hùng</option>
                            <option name="key_word" {{isset($request['currency']) && $request['currency'] == 'Gia đình có công với cách mạng' ? 'selected' : ''}} value="Gia đình có công với cách mạng">Gia đình có công với cách mạng</option>
                            <option name="key_word" {{isset($request['currency']) && $request['currency'] == 'Gia đình liệt sĩ' ? 'selected' : ''}} value="Gia đình liệt sĩ">Gia đình liệt sĩ</option>
                            <option name="key_word" {{isset($request['currency']) && $request['currency'] == 'Thương binh' ? 'selected' : ''}} value="Thương binh">Thương binh</option>
                            <option name="key_word" {{isset($request['currency']) && $request['currency'] == 'Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng' ? 'selected' : ''}} value="Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng">Gia đình anh hùng lực lượng vũ trang được nhà nước phong tặng</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="town">
                            <option name="key_word" value="">-Xã - Phường-</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Ba Láng' ? 'selected' : ''}} value="Ba Láng">Ba Láng</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Hưng Phú' ? 'selected' : ''}} value="Hưng Phú">Hưng Phú</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Hưng Thạnh' ? 'selected' : ''}} value="Hưng Thạnh">Hưng Thạnh</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Lê Bình' ? 'selected' : ''}} value="Lê Bình">Lê Bình</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Phú Thứ' ? 'selected' : ''}} value="Phú Thứ">Phú Thứ</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Tân Phú' ? 'selected' : ''}} value="Tân Phú">Tân Phú</option>
                            <option name="key_word" {{isset($request['town']) && $request['town'] == 'Thường Thạnh' ? 'selected' : ''}} value="Thường Thạnh">Thường Thạnh</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-info">Lọc</button>
                    </div>
                </div>
                {!!Form::close()!!}
                <div class="card-header"><h3 style="text-align: center">DANH SÁCH NGƯỜI NHẬN TIỀN</h3></div>
                <div class="card">
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Họ và tên</th>
                                <th scope="col">Ngày sinh</th>
                                <th scope="col">Số điện thoại</th>
                                {{--<th scope="col">Địa chỉ</th>--}}
                                {{--<th scope="col">Xã - Phường</th>--}}
                                {{--<th scope="col">Quận - Huyện</th>--}}
                                {{--<th scope="col">Tỉnh - Thành phố</th>--}}
                                <th scope="col">Số CMND</th>
                                <th scope="col">Ngày cấp CMND</th>
                                <th scope="col">Nơi cấp CMND</th>
                                <th scope="col">Số tiền</th>
                                <th scope="col">Loại tiền</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach($users as $key=>$value)
                                    <tr>
                                        <th scope="row">{{$key+1}}</th>
                                        <td>{{$value->name}}</td>
                                        <td>{{$value->birthday}}</td>
                                        <td>{{$value->phone_number}}</td>
                                        {{--<td>{{$value->address}}</td>--}}
                                        {{--<td>{{$value->town}}</td>--}}
                                        {{--<td>{{$value->district}}</td>--}}
                                        {{--<td>{{$value->city}}</td>--}}
                                        <td>{{$value->id_card}}</td>
                                        <td>{{$value->date_card}}</td>
                                        <td>{{$value->place_card}}</td>
                                        <td>{{$value->money}}</td>
                                        <td>{{$value->currency}}</td>
                                        <td>
                                            <a  href="{{url('recipients/'.$value->id.'/edit')}}" style="margin-bottom: 10px;" class="btn btn-success colorBule">Sửa</a>
                                            {!!Form::open(['action' => ['RecipientsController@destroy', $value->id], 'method' => 'POTS', 'class' => 'pull-right'])!!}
                                            {{Form::hidden('_method', 'DELETE')}}
                                            {{Form::submit('Xóa', ['class' => 'btn btn-danger'])}}
                                            {!!Form::close()!!}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection